package com.example.data

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

interface AladhanApi {
    @GET("v1/timings")
    suspend fun getTimings(
        @Query("latitude") latitude: String = "30.0444",
        @Query("longitude") longitude: String = "31.2357",
        @Query("method") method: String = "5"
    ): AladhanResponse

    companion object {
        private const val BASE_URL = "https://api.aladhan.com/"

        fun create(): AladhanApi {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(AladhanApi::class.java)
        }
    }
}
