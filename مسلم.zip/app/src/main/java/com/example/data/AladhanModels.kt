package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AladhanResponse(
    @Json(name = "code") val code: Int,
    @Json(name = "status") val status: String,
    @Json(name = "data") val data: AladhanData
)

@JsonClass(generateAdapter = true)
data class AladhanData(
    @Json(name = "timings") val timings: Timings,
    @Json(name = "date") val date: DateInfo
)

@JsonClass(generateAdapter = true)
data class Timings(
    @Json(name = "Fajr") val fajr: String,
    @Json(name = "Sunrise") val sunrise: String,
    @Json(name = "Dhuhr") val dhuhr: String,
    @Json(name = "Asr") val asr: String,
    @Json(name = "Maghrib") val maghrib: String,
    @Json(name = "Isha") val isha: String
)

@JsonClass(generateAdapter = true)
data class DateInfo(
    @Json(name = "readable") val readable: String,
    @Json(name = "hijri") val hijri: HijriInfo
)

@JsonClass(generateAdapter = true)
data class HijriInfo(
    @Json(name = "date") val date: String,
    @Json(name = "day") val day: String,
    @Json(name = "month") val month: HijriMonth,
    @Json(name = "year") val year: String,
    @Json(name = "holidays") val holidays: List<String>
)

@JsonClass(generateAdapter = true)
data class HijriMonth(
    @Json(name = "number") val number: Int,
    @Json(name = "en") val en: String,
    @Json(name = "ar") val ar: String
)
