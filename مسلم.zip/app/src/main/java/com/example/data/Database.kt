package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "completed_tasks")
data class CompletedTask(
    @PrimaryKey val taskId: Int,
    val dateString: String
)

@Entity(tableName = "app_state")
data class AppState(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface MuslimDao {
    @Query("SELECT * FROM completed_tasks WHERE dateString = :dateString")
    fun getCompletedTasksForDate(dateString: String): Flow<List<CompletedTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun completeTask(task: CompletedTask)

    @Query("DELETE FROM completed_tasks WHERE taskId = :taskId AND dateString = :dateString")
    suspend fun uncompleteTask(taskId: Int, dateString: String)

    @Query("SELECT * FROM app_state WHERE `key` = :key")
    suspend fun getAppState(key: String): AppState?

    @Query("SELECT * FROM app_state WHERE `key` = :key")
    fun getAppStateFlow(key: String): Flow<AppState?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAppState(appState: AppState)
}

@Database(entities = [CompletedTask::class, AppState::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun muslimDao(): MuslimDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "muslim_app_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
