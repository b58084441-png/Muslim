package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MuslimRepository(
    private val api: AladhanApi,
    private val dao: MuslimDao
) {
    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getCompletedTasksForToday(): Flow<List<CompletedTask>> {
        return dao.getCompletedTasksForDate(getTodayDateString())
    }

    suspend fun toggleTaskComplete(taskId: Int, currentCompleted: Boolean) {
        val dateString = getTodayDateString()
        if (currentCompleted) {
            dao.uncompleteTask(taskId, dateString)
        } else {
            dao.completeTask(CompletedTask(taskId, dateString))
        }
    }

    fun getTasbihCounterFlow(): Flow<AppState?> {
        return dao.getAppStateFlow("tasbih_count")
    }

    suspend fun saveTasbihCounter(count: Int) {
        dao.saveAppState(AppState("tasbih_count", count.toString()))
    }

    suspend fun fetchPrayerTimings(lat: String = "30.0444", lng: String = "31.2357"): AladhanResponse {
        return api.getTimings(latitude = lat, longitude = lng, method = "5")
    }
}
