package com.example.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class AudioType {
    NONE, SURAH, RADIO
}

class AudioPlayerManager(private val context: Context) {
    private var mainPlayer: MediaPlayer? = null
    private var azanPlayer: MediaPlayer? = null

    private val _currentAudioType = MutableStateFlow(AudioType.NONE)
    val currentAudioType: StateFlow<AudioType> = _currentAudioType

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _currentSurahName = MutableStateFlow("")
    val currentSurahName: StateFlow<String> = _currentSurahName

    private val _isAzanMuted = MutableStateFlow(false)
    val isAzanMuted: StateFlow<Boolean> = _isAzanMuted

    fun toggleAzanMute() {
        _isAzanMuted.value = !_isAzanMuted.value
        if (_isAzanMuted.value) {
            stopAzanPlayer()
        }
    }

    fun playAudio(url: String, type: AudioType, label: String = "") {
        _isLoading.value = true
        _isPlaying.value = false
        stopMainPlayer()
        // Terminate any ongoing active Azan if user explicitly interacts with the app
        stopAzanPlayer()

        try {
            mainPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener {
                    _isLoading.value = false
                    _isPlaying.value = true
                    _currentAudioType.value = type
                    _currentSurahName.value = label
                    start()
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    _currentAudioType.value = AudioType.NONE
                    _currentSurahName.value = ""
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerManager", "MediaPlayer error: $what, $extra")
                    _isLoading.value = false
                    _isPlaying.value = false
                    _currentAudioType.value = AudioType.NONE
                    _currentSurahName.value = ""
                    false
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("AudioPlayerManager", "Error playing media source: $url", e)
            _isLoading.value = false
        }
    }

    fun stopMainPlayer() {
        mainPlayer?.let {
            try {
                if (it.isPlaying) {
                    it.stop()
                }
            } catch (e: Exception) {
                Log.e("AudioPlayerManager", "Error stopping main player", e)
            }
            it.release()
        }
        mainPlayer = null
        _isPlaying.value = false
        _currentAudioType.value = AudioType.NONE
        _currentSurahName.value = ""
    }

    fun playAzan() {
        if (_isAzanMuted.value) return

        stopMainPlayer()
        stopAzanPlayer()

        try {
            val url = "https://download.tvquran.com/download/selections/32/6063cb53aa090.mp3"
            azanPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener {
                    start()
                }
                setOnCompletionListener {
                    stopAzanPlayer()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerManager", "Azan MediaPlayer error: $what, $extra")
                    false
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("AudioPlayerManager", "Error setting up Azan player", e)
        }
    }

    fun stopAzanPlayer() {
        azanPlayer?.let {
            try {
                if (it.isPlaying) {
                    it.stop()
                }
            } catch (e: Exception) {
                Log.e("AudioPlayerManager", "Error stopping Azan player", e)
            }
            it.release()
        }
        azanPlayer = null
    }

    fun release() {
        stopMainPlayer()
        stopAzanPlayer()
    }
}
