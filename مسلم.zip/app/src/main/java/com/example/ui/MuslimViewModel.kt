package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.media.AudioPlayerManager
import com.example.media.AudioType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class TimingsState(
    val fajr: String = "04:38",
    val sunrise: String = "06:05",
    val dhuhr: String = "12:04",
    val asr: String = "15:29",
    val maghrib: String = "18:03",
    val isha: String = "19:21"
)

data class PrayerTimesUIState(
    val isLoading: Boolean = false,
    val timings: TimingsState = TimingsState(),
    val hijriDate: String = "جاري تحميل التاريخ الهجري...",
    val holidays: List<String> = emptyList(),
    val error: String? = null
)

data class CountdownState(
    val nextPrayerName: String = "الفجر",
    val nextPrayerTime: String = "04:38",
    val countdownString: String = "00:00"
)

class MuslimViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val api = AladhanApi.create()
    private val repository = MuslimRepository(api, database.muslimDao())
    val audioPlayerManager = AudioPlayerManager(application)

    private val _uiState = MutableStateFlow(PrayerTimesUIState())
    val uiState: StateFlow<PrayerTimesUIState> = _uiState.asStateFlow()

    private val _countdownState = MutableStateFlow(CountdownState())
    val countdownState: StateFlow<CountdownState> = _countdownState.asStateFlow()

    private val _completedTaskIds = MutableStateFlow<Set<Int>>(emptySet())
    val completedTaskIds: StateFlow<Set<Int>> = _completedTaskIds.asStateFlow()

    private val _tasbihCount = MutableStateFlow(0)
    val tasbihCount: StateFlow<Int> = _tasbihCount.asStateFlow()

    private val _quranSearchQuery = MutableStateFlow("")
    val quranSearchQuery: StateFlow<String> = _quranSearchQuery.asStateFlow()

    private var timerJob: Job? = null
    private var lastPlayedAzanTime: String = ""

    // Static Data
    val dailyTasks = listOf(
        DailyTask(1, "أذكار الصباح", true),
        DailyTask(2, "ورد القرآن اليومي", false),
        DailyTask(3, "صلاة الضحى", true),
        DailyTask(4, "الاستغفار (100 مرة)", false),
        DailyTask(5, "صلاة الوتر", true)
    )

    val tasbihPhrases = listOf("سُبْحَانَ اللَّه", "الْحَمْدُ لِلَّه", "اللَّهُ أَكْبَر", "لَا إِلٰهَ إِلَّا اللَّه")

    val adhkarList = listOf(
        "أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له",
        "رضيت بالله رباً، وبالإسلام ديناً، وبمحمد صلى الله عليه وسلم نبياً",
        "سبحان الله وبحمده: عدد خلقه، ورضا نفسه، وزنة عرشه",
        "اللهم إني أسألك علماً نافعاً، ورزقاً طيباً، وعملاً متقبلاً",
        "يا حي يا قيوم برحمتك أستغيث أصلح لي شأني كله ولا تكلني إلى نفسي طرفة عين",
        "اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت",
        "أعوذ بكلمات الله التامات من شر ما خلق",
        "اللهم بك أصبحنا، وبك أمسينا، وبك نحيا، وبك نموت، وإليك النشور",
        "حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم (7 مرات)",
        "بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم",
        "اللهم عافني في بدني، اللهم عافني في سمعي، اللهم عافني في بصري، لا إله إلا أنت",
        "اللهم إني أعوذ بك من الكفر، والفقر، وأعوذ بك من عذاب القبر، لا إله إلا أنت",
        "لا إله إلا الله وحده لا شريك له، له الملك وله الحمد، وهو على كل شيء قدير (100 مرة)",
        "سبحان الله وبحمده (100 مرة)",
        "أستغفر الله وأتوب إليه (100 مرة)",
        "اللهم صل وسلم على نبينا محمد (10 مرات)",
        "اللهم إني أسألك العفو والعافية في الدنيا والآخرة",
        "اللهم استر عوراتي، وآمن روعاتي، واحفظني من بين يدي ومن خلفي",
        "اللهم فاطر السموات والأرض رب كل شيء ومليكه، أشهد أن لا إله إلا أنت",
        "أصبحنا على فطرة الإسلام، وعلى كلمة الإخلاص، وعلى دين نبينا محمد"
    )

    val namesOfAllah = listOf(
        "الرحمن", "الرحيم", "الملك", "القدوس", "السلام", "المؤمن", "المهيمن", "العزيز", "الجبار", "المتكبر",
        "الخالق", "البارئ", "المصور", "الغفار", "القهار", "الوهاب", "الرزاق", "الفتاح", "العليم", "القابض",
        "الباسط", "الخافض", "الرافع", "المعز", "المذل", "السميع", "البصير", "الحكم", "العدل", "اللطيف",
        "الخبير", "الحليم", "العظيم", "الغفور", "الشكور", "العلي", "الكبير", "الحفيظ", "المقيت", "الحسيب",
        "الجليل", "الكريم", "الرقيب", "المجيب", "الواسع", "الحكيم", "الودود", "المجيد", "الباعث", "الشهيد",
        "الحق", "الوكيل", "القوي", "المتين", "الولي", "الحميد", "المحصي", "المبدئ", "المعيد", "المحيي",
        "المميت", "الحي", "القيوم", "الواجد", "الماجد", "الواحد", "الأحد", "الصمد", "القادر", "المقتدر",
        "المقدم", "المؤخر", "الأول", "الآخر", "الظاهر", "الباطن", "الوالي", "المتعالي", "البر", "التواب",
        "المنتقم", "العفو", "الرؤوف", "مالك الملك", "ذو الجلال والإكرام", "المقسط", "الجامع", "الغني", "المغني", "المانع",
        "الضار", "النافع", "النور", "الهادي", "البديع", "الباقي", "الوارث", "الرشيد", "الصبور"
    )

    val surahs = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
        "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
        "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
        "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
        "المسد", "الإخلاص", "الفلق", "الناس"
    )

    init {
        fetchPrayerTimings()
        observeDatabase()
        startCountdownTimer()
    }

    private fun fetchPrayerTimings() {
        _uiState.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            try {
                val response = repository.fetchPrayerTimings()
                if (response.code == 200) {
                    val t = response.data.timings
                    val hijri = response.data.date.hijri
                    val dateFormatted = "${hijri.day} ${hijri.month.ar} ${hijri.year} هـ"

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            timings = TimingsState(
                                fajr = t.fajr,
                                sunrise = t.sunrise,
                                dhuhr = t.dhuhr,
                                asr = t.asr,
                                maghrib = t.maghrib,
                                isha = t.isha
                            ),
                            hijriDate = dateFormatted,
                            holidays = hijri.holidays,
                            error = null
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, error = "API returned code ${response.code}") }
                }
            } catch (e: Exception) {
                // Fallback to local default Egyptian calculations
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        hijriDate = getTodayHijriFallback(),
                        error = "Offline mode active"
                    )
                }
            }
        }
    }

    private fun observeDatabase() {
        viewModelScope.launch {
            repository.getCompletedTasksForToday().collect { completedList ->
                _completedTaskIds.value = completedList.map { it.taskId }.toSet()
            }
        }

        viewModelScope.launch {
            repository.getTasbihCounterFlow().collect { appState ->
                _tasbihCount.value = appState?.value?.toIntOrNull() ?: 0
            }
        }
    }

    private fun startCountdownTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                calculateCountdown()
                delay(1000)
            }
        }
    }

    private fun calculateCountdown() {
        val timings = _uiState.value.timings
        val calendar = Calendar.getInstance()
        val currentHours = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinutes = calendar.get(Calendar.MINUTE)
        val currentSeconds = calendar.get(Calendar.SECOND)
        val currentMinsOfDay = currentHours * 60 + currentMinutes

        val prayerNames = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
        val prayerTimes = listOf(
            timings.fajr,
            timings.sunrise,
            timings.dhuhr,
            timings.asr,
            timings.maghrib,
            timings.isha
        )

        var minDiff = Int.MAX_VALUE
        var nextName = "الفجر"
        var nextTime = timings.fajr

        for (i in prayerTimes.indices) {
            val pMins = timeToMinutes(prayerTimes[i])
            var diff = pMins - currentMinsOfDay
            if (diff < 0) {
                diff += 1440 // Over midnight
            }
            if (diff < minDiff && diff >= 0) {
                // To avoid countdown hitting 0 and immediate skip, check if it's currently that exact minute
                if (diff == 0 && currentSeconds == 0) {
                    val prayerName = prayerNames[i]
                    if (prayerName != "الشروق" && lastPlayedAzanTime != currentTimeString(currentHours, currentMinutes)) {
                        lastPlayedAzanTime = currentTimeString(currentHours, currentMinutes)
                        audioPlayerManager.playAzan()
                    }
                }
                minDiff = diff
                nextName = prayerNames[i]
                nextTime = prayerTimes[i]
            }
        }

        // If after Isha, the next is Fajr tomorrow
        if (minDiff == Int.MAX_VALUE) {
            minDiff = (timeToMinutes(timings.fajr) - currentMinsOfDay) + 1440
            nextName = "الفجر"
            nextTime = timings.fajr
        }

        val hours = minDiff / 60
        val mins = minDiff % 60
        _countdownState.value = CountdownState(
            nextPrayerName = nextName,
            nextPrayerTime = nextTime,
            countdownString = "${hours}س و ${mins}د"
        )
    }

    private fun currentTimeString(hours: Int, minutes: Int): String {
        return String.format(Locale.US, "%02d:%02d", hours, minutes)
    }

    private fun timeToMinutes(timeStr: String): Int {
        val cleanStr = timeStr.substringBefore(" ").trim()
        val parts = cleanStr.split(":")
        if (parts.size < 2) return 0
        val h = parts[0].toIntOrNull() ?: 0
        val m = parts[1].toIntOrNull() ?: 0
        return h * 60 + m
    }

    fun formatTo12h(timeStr: String): String {
        val cleanStr = timeStr.substringBefore(" ").trim()
        val parts = cleanStr.split(":")
        if (parts.size < 2) return timeStr
        val h = parts[0].toIntOrNull() ?: 0
        val m = parts[1].toIntOrNull() ?: 0
        val period = if (h >= 12) "م" else "ص"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.getDefault(), "%d:%02d %s", h12, m, period)
    }

    fun toggleTask(taskId: Int) {
        val currentCompleted = _completedTaskIds.value.contains(taskId)
        viewModelScope.launch {
            repository.toggleTaskComplete(taskId, currentCompleted)
        }
    }

    fun incrementTasbih() {
        val nextCount = _tasbihCount.value + 1
        _tasbihCount.value = nextCount
        viewModelScope.launch {
            repository.saveTasbihCounter(nextCount)
        }
    }

    fun resetTasbih() {
        _tasbihCount.value = 0
        viewModelScope.launch {
            repository.saveTasbihCounter(0)
        }
    }

    fun updateQuranSearchQuery(query: String) {
        _quranSearchQuery.value = query
    }

    fun toggleRadio() {
        val state = audioPlayerManager.currentAudioType.value
        if (state == AudioType.RADIO && audioPlayerManager.isPlaying.value) {
            audioPlayerManager.stopMainPlayer()
        } else {
            // Live Cairo FM stream link
            val radioUrl = "https://n03.radiojar.com/8s5u8p3pzhquv"
            audioPlayerManager.playAudio(radioUrl, AudioType.RADIO, "إذاعة القرآن الكريم")
        }
    }

    fun playSurah(id: Int, name: String) {
        val formattedId = String.format(Locale.US, "%03d", id)
        val url = "https://server8.mp3quran.net/afs/$formattedId.mp3"
        audioPlayerManager.playAudio(url, AudioType.SURAH, "سورة $name")
    }

    private fun getTodayHijriFallback(): String {
        // Fallback calculation using standard calendars
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH) + 1
        val year = calendar.get(Calendar.YEAR)
        // Approximate standard Islamic calendar calculation
        val currentYearHijri = (year - 622) * 33 / 32
        return "$day ذو الحجة $currentYearHijri هـ" // fallback Arabic placeholder
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        audioPlayerManager.release()
    }
}

data class DailyTask(val id: Int, val text: String, val recommended: Boolean)
