package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark Emerald & Jade tones
val EmeraldDark = Color(0xFF011A14)
val EmeraldMedium = Color(0xFF022C22)
val EmeraldLight = Color(0xFF064E3B)
val EmeraldAccent = Color(0xFF10B981)

// Rich Sage light contrasts
val SageLight = Color(0xFFECFDF5)
val SageMuted = Color(0xFFD1FAE5)

// Golden tones for luxury gradients
val GoldDeep = Color(0xFFB38728)
val GoldPure = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFBF5B7)
val GoldShiny = Color(0xFFFCF6BA)
val GoldMetallic = Color(0xFFBF953F)
