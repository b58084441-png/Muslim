package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.media.AudioType
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*

enum class Tab {
    HOME, TASKS, QURAN, ARIA
}

enum class AriaSubScreen {
    MAIN, ADHKAR, NAMES, TASBIH, QIBLA, HOLIDAYS
}

val GoldGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFFBF953F),
        Color(0xFFFCF6BA),
        Color(0xFFB38728),
        Color(0xFFFBF5B7)
    )
)

val PrimaryDarkGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF010E0B),
        Color(0xFF011A14),
        Color(0xFF022C22)
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MuslimApp(viewModel: MuslimViewModel) {
    var currentTab by remember { mutableStateOf(Tab.HOME) }
    var activeAriaScreen by remember { mutableStateOf(AriaSubScreen.MAIN) }
    
    val uiState by viewModel.uiState.collectAsState()
    val countdownState by viewModel.countdownState.collectAsState()
    val completedTaskIds by viewModel.completedTaskIds.collectAsState()
    val tasbihCount by viewModel.tasbihCount.collectAsState()
    val quranQuery by viewModel.quranSearchQuery.collectAsState()
    
    val isMediaPlaying by viewModel.audioPlayerManager.isPlaying.collectAsState()
    val isMediaLoading by viewModel.audioPlayerManager.isLoading.collectAsState()
    val currentAudioType by viewModel.audioPlayerManager.currentAudioType.collectAsState()
    val currentPlayingLabel by viewModel.audioPlayerManager.currentSurahName.collectAsState()
    val isAzanMuted by viewModel.audioPlayerManager.isAzanMuted.collectAsState()

    val scope = rememberCoroutineScope()
    var successToastMessage by remember { mutableStateOf<String?>(null) }

    // Floating success greeting animation
    LaunchedEffect(successToastMessage) {
        if (successToastMessage != null) {
            delay(2500)
            successToastMessage = null
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF011A14)),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF011A14),
                    titleContentColor = Color.White
                ),
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, GoldPure, CircleShape)
                                    .background(Color(0xFF022C22)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Mosque Emblem",
                                    tint = GoldPure,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "مسلم",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 24.sp,
                                        color = Color.White
                                    )
                                )
                                Text(
                                    text = "Dev. Abdulaziz Mohammed",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 9.sp,
                                        color = GoldPure,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                        }

                        // Right header items: Equalizer sound flow and bell notification toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isMediaPlaying) {
                                AudioVisualizer()
                            }
                            IconButton(
                                onClick = { viewModel.audioPlayerManager.toggleAzanMute() },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color.White.copy(alpha = 0.05f), CircleShape)
                                    .border(0.5.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isAzanMuted) Icons.Default.NotificationsOff else Icons.Default.NotificationsActive,
                                    contentDescription = "Toggle Mute",
                                    tint = if (isAzanMuted) Color.White.copy(alpha = 0.4f) else GoldPure,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .border(1.dp, GoldPure.copy(alpha = 0.3f), RoundedCornerShape(32.dp)),
                containerColor = Color(0xFF022C22).copy(alpha = 0.95f),
                tonalElevation = 12.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == Tab.HOME,
                    onClick = {
                        currentTab = Tab.HOME
                        activeAriaScreen = AriaSubScreen.MAIN
                    },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("الرئيسية", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = GoldPure,
                        indicatorColor = GoldPure,
                        unselectedIconColor = Color.White.copy(alpha = 0.4f),
                        unselectedTextColor = Color.White.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = currentTab == Tab.TASKS,
                    onClick = {
                        currentTab = Tab.TASKS
                        activeAriaScreen = AriaSubScreen.MAIN
                    },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Tasks") },
                    label = { Text("خطتي", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = GoldPure,
                        indicatorColor = GoldPure,
                        unselectedIconColor = Color.White.copy(alpha = 0.4f),
                        unselectedTextColor = Color.White.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_tasks")
                )
                NavigationBarItem(
                    selected = currentTab == Tab.QURAN,
                    onClick = {
                        currentTab = Tab.QURAN
                        activeAriaScreen = AriaSubScreen.MAIN
                    },
                    icon = { Icon(Icons.Default.Book, contentDescription = "Quran") },
                    label = { Text("القرآن", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = GoldPure,
                        indicatorColor = GoldPure,
                        unselectedIconColor = Color.White.copy(alpha = 0.4f),
                        unselectedTextColor = Color.White.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_quran")
                )
                NavigationBarItem(
                    selected = currentTab == Tab.ARIA,
                    onClick = { currentTab = Tab.ARIA },
                    icon = { Icon(Icons.Default.Widgets, contentDescription = "Aria") },
                    label = { Text("اريا", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = GoldPure,
                        indicatorColor = GoldPure,
                        unselectedIconColor = Color.White.copy(alpha = 0.4f),
                        unselectedTextColor = Color.White.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("nav_aria")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PrimaryDarkGradient)
        ) {
            // Main body switcher
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "tab_switch"
            ) { targetTab ->
                when (targetTab) {
                    Tab.HOME -> HomeScreen(
                        uiState = uiState,
                        countdownState = countdownState,
                        isMediaPlaying = isMediaPlaying,
                        isMediaLoading = isMediaLoading,
                        currentAudioType = currentAudioType,
                        onRadioToggle = { viewModel.toggleRadio() },
                        formatTo12h = { viewModel.formatTo12h(it) }
                    )
                    Tab.TASKS -> TasksScreen(
                        dailyTasks = viewModel.dailyTasks,
                        completedTaskIds = completedTaskIds,
                        onToggleTask = { id, text ->
                            viewModel.toggleTask(id)
                            if (!completedTaskIds.contains(id)) {
                                successToastMessage = "تم إنجاز: $text \nبارك الله فيك وتقبل منك!"
                            }
                        }
                    )
                    Tab.QURAN -> QuranScreen(
                        surahs = viewModel.surahs,
                        quranQuery = quranQuery,
                        currentPlayingLabel = currentPlayingLabel,
                        isMediaPlaying = isMediaPlaying,
                        isMediaLoading = isMediaLoading,
                        onSearchChange = { viewModel.updateQuranSearchQuery(it) },
                        onSurahClick = { index, name -> viewModel.playSurah(index, name) },
                        onStopClick = { viewModel.audioPlayerManager.stopMainPlayer() }
                    )
                    Tab.ARIA -> AriaScreen(
                        activeScreen = activeAriaScreen,
                        viewModel = viewModel,
                        tasbihCount = tasbihCount,
                        onScreenChange = { activeAriaScreen = it },
                        onSuccessComplete = { successToastMessage = it }
                    )
                }
            }

            // Universal Floating Active Audio Banner (If playing a Quran surah)
            if (currentTab != Tab.QURAN && isMediaPlaying && currentPlayingLabel.startsWith("سورة")) {
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
                        .fillMaxWidth()
                        .animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF022C22)),
                    border = BorderStroke(1.dp, GoldPure.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(GoldGradient, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Mishary", tint = EmeraldDark)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = currentPlayingLabel,
                                    style = TextStyle(color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                )
                                Text(
                                    text = "القارئ مشاري العفاسي",
                                    style = TextStyle(color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                                )
                            }
                        }
                        IconButton(
                            onClick = { viewModel.audioPlayerManager.stopMainPlayer() },
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color.White, CircleShape)
                        ) {
                            Icon(Icons.Default.Pause, contentDescription = "Stop", tint = EmeraldDark)
                        }
                    }
                }
            }

            // High aesthetic congratulatory standard popup
            AnimatedVisibility(
                visible = successToastMessage != null,
                enter = fadeIn() + slideInVertically { -40 },
                exit = fadeOut() + slideOutVertically { -40 },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GoldPure),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(8.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Success Star",
                            tint = EmeraldDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = successToastMessage ?: "",
                            style = TextStyle(
                                color = EmeraldDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        )
                    }
                }
            }
        }
    }
}

// 1. --- HOME TAB COMPONENT ---
@Composable
fun HomeScreen(
    uiState: PrayerTimesUIState,
    countdownState: CountdownState,
    isMediaPlaying: Boolean,
    isMediaLoading: Boolean,
    currentAudioType: AudioType,
    onRadioToggle: () -> Unit,
    formatTo12h: (String) -> String
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)
    ) {
        // High-altitude sunset theme prayer banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(36.dp))
                    .border(2.dp, GoldPure, RoundedCornerShape(36.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF047857),
                                Color(0xFF065F46),
                                Color(0xFF011A14)
                            )
                        )
                    )
            ) {
                // Vector drawn Islamic domes backdrop
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(0.08f)
                ) {
                    val archWidth = size.width / 3f
                    val archHeight = size.height * 0.4f
                    val path = Path().apply {
                        moveTo(0f, size.height)
                        // arch 1
                        cubicTo(archWidth * 0.2f, size.height - archHeight, archWidth * 0.8f, size.height - archHeight, archWidth, size.height)
                        // arch 2 (dominant middle)
                        cubicTo(archWidth + (archWidth * 0.1f), size.height - archHeight * 1.5f, archWidth + (archWidth * 0.9f), size.height - archHeight * 1.5f, archWidth * 2f, size.height)
                        // arch 3
                        cubicTo(archWidth * 2f + (archWidth * 0.2f), size.height - archHeight, archWidth * 2f + (archWidth * 0.8f), size.height - archHeight, size.width, size.height)
                    }
                    drawPath(path, color = GoldPure, style = Stroke(width = 4f))
                }

                // Banner Details
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Text(
                        text = uiState.hijriDate,
                        style = TextStyle(
                            color = GoldLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "الصلاة القادمة: " + countdownState.nextPrayerName,
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Timer Capsule
                    Row(
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(50.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(50.dp))
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = formatTo12h(countdownState.nextPrayerTime),
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(20.dp)
                                .background(Color.White.copy(alpha = 0.3f))
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "متبقي",
                                style = TextStyle(color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                            )
                            Text(
                                text = countdownState.countdownString,
                                style = TextStyle(color = GoldShiny, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        // Live Cairo Quran Radio Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onRadioToggle() },
                colors = CardDefaults.cardColors(containerColor = SageLight),
                shape = RoundedCornerShape(28.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(GoldGradient, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isMediaLoading && currentAudioType == AudioType.RADIO) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = EmeraldDark, strokeWidth = 2.5.dp)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Radio,
                                    contentDescription = "Radio Icon",
                                    tint = EmeraldDark,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "إذاعة القرآن الكريم",
                                    style = TextStyle(
                                        color = EmeraldDark,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp
                                    )
                                )
                                if (isMediaPlaying && currentAudioType == AudioType.RADIO) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(Color.Red, CircleShape)
                                    )
                                }
                            }
                            Text(
                                text = "بث مباشر من القاهرة",
                                style = TextStyle(color = EmeraldDark.copy(alpha = 0.6f), fontSize = 11.sp)
                            )
                        }
                    }

                    // Circular action play trigger
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(EmeraldDark, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMediaPlaying && currentAudioType == AudioType.RADIO) {
                                Icons.Default.Pause
                            } else {
                                Icons.Default.PlayArrow
                            },
                            contentDescription = "Toggle Radio stream",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // 6 Prayer Times localized grid
        item {
            val timings = uiState.timings
            val prayers = listOf(
                "الفجر" to timings.fajr,
                "الشروق" to timings.sunrise,
                "الظهر" to timings.dhuhr,
                "العصر" to timings.asr,
                "المغرب" to timings.maghrib,
                "العشاء" to timings.isha
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Header Label
                Text(
                    text = "مواقيت صلاة اليوم بالقاهرة",
                    style = TextStyle(color = GoldPure, fontSize = 14.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    prayers.take(3).forEach { prayer ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                                .padding(vertical = 16.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = prayer.first,
                                    style = TextStyle(color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = formatTo12h(prayer.second),
                                    style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    prayers.drop(3).forEach { prayer ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                                .padding(vertical = 16.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = prayer.first,
                                    style = TextStyle(color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = formatTo12h(prayer.second),
                                    style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quranic Wisdom card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SageLight),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, GoldPure.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نور من الحكمة",
                            style = TextStyle(color = Color(0xFFB38728), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        )
                        Icon(Icons.Default.StarBorder, contentDescription = "Star", tint = Color(0xFFB38728))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "\"مَنْ كَانَ يُرِيدُ الْعِزَّةَ فَلِلَّهِ الْعِزَّةُ جَمِيعًا\"",
                        style = TextStyle(
                            color = EmeraldDark,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

// 2. --- TASKS TAB COMPONENT ---
@Composable
fun TasksScreen(
    dailyTasks: List<DailyTask>,
    completedTaskIds: Set<Int>,
    onToggleTask: (Int, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "خطة اليوم الروحية",
            style = TextStyle(color = GoldPure, fontSize = 22.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Progress bar indicator
        val completedCount = dailyTasks.count { completedTaskIds.contains(it.id) }
        val progressPercent = if (dailyTasks.isNotEmpty()) completedCount.toFloat() / dailyTasks.size else 0f

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("أهداف اليوم الروحية", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("$completedCount من ${dailyTasks.size}", color = GoldPure, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progressPercent },
                    color = GoldPure,
                    trackColor = Color.White.copy(alpha = 0.1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(dailyTasks) { task ->
                val isCompleted = completedTaskIds.contains(task.id)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleTask(task.id, task.text) },
                    colors = CardDefaults.cardColors(containerColor = SageLight),
                    shape = RoundedCornerShape(24.dp),
                    border = if (isCompleted) BorderStroke(1.5.dp, GoldPure) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isCompleted) GoldPure else EmeraldDark.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isCompleted) {
                                    Icon(Icons.Default.Check, contentDescription = "Checked", tint = EmeraldDark, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = task.text,
                                style = TextStyle(
                                    color = EmeraldDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                            )
                        }

                        if (task.recommended) {
                            Box(
                                modifier = Modifier
                                    .background(GoldGradient, RoundedCornerShape(50.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "موصى به",
                                    style = TextStyle(color = EmeraldDark, fontSize = 8.sp, fontWeight = FontWeight.Black)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. --- QURAN TAB COMPONENT ---
@Composable
fun QuranScreen(
    surahs: List<String>,
    quranQuery: String,
    currentPlayingLabel: String,
    isMediaPlaying: Boolean,
    isMediaLoading: Boolean,
    onSearchChange: (String) -> Unit,
    onSurahClick: (Int, String) -> Unit,
    onStopClick: () -> Unit
) {
    val filteredSurahs = remember(quranQuery, surahs) {
        if (quranQuery.isBlank()) {
            surahs.mapIndexed { index, name -> index + 1 to name }
        } else {
            surahs.mapIndexed { index, name -> index + 1 to name }
                .filter { it.second.contains(quranQuery) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "المصحف المرتل",
            style = TextStyle(color = GoldPure, fontSize = 22.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Islamic search bar
        OutlinedTextField(
            value = quranQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("ابحث عن سورة...", color = Color.White.copy(alpha = 0.4f)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldPure) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedBorderColor = GoldPure,
                unfocusedBorderColor = Color.White.copy(alpha = 0.15f)
            ),
            shape = RoundedCornerShape(20.dp),
            singleLine = true
        )

        // Local active playing card if actively streaming a surah
        if (isMediaPlaying && currentPlayingLabel.startsWith("سورة")) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF022C22)),
                border = BorderStroke(2.dp, GoldPure),
                shape = RoundedCornerShape(28.dp)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(GoldGradient, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Sound Wave", tint = EmeraldDark, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("تستمع حالياً", color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(currentPlayingLabel, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    IconButton(
                        onClick = onStopClick,
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color.White, CircleShape)
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause", tint = EmeraldDark)
                    }
                }
            }
        }

        // Lazy Surahs column
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredSurahs) { (id, name) ->
                val surahLabel = "سورة $name"
                val isCurrent = currentPlayingLabel == surahLabel

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSurahClick(id, name) },
                    colors = CardDefaults.cardColors(containerColor = SageLight),
                    shape = RoundedCornerShape(20.dp),
                    border = if (isCurrent) BorderStroke(1.5.dp, GoldPure) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = String.format(Locale.US, "%03d", id),
                                style = TextStyle(color = EmeraldDark.copy(alpha = 0.3f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = name,
                                style = TextStyle(color = EmeraldDark, fontWeight = FontWeight.Bold, fontSize = 18.sp, fontFamily = FontFamily.Serif)
                            )
                        }

                        if (isCurrent && isMediaLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = EmeraldDark, strokeWidth = 2.dp)
                        } else {
                            Icon(
                                imageVector = if (isCurrent) Icons.Default.VolumeUp else Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = if (isCurrent) GoldDeep else EmeraldDark.copy(alpha = 0.2f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// 4. --- ARIA TOOLSET COMPONENT ---
@Composable
fun AriaScreen(
    activeScreen: AriaSubScreen,
    viewModel: MuslimViewModel,
    tasbihCount: Int,
    onScreenChange: (AriaSubScreen) -> Unit,
    onSuccessComplete: (String) -> Unit
) {
    AnimatedContent(
        targetState = activeScreen,
        transitionSpec = {
            fadeIn() togetherWith fadeOut()
        },
        label = "aria_sw"
    ) { screen ->
        when (screen) {
            AriaSubScreen.MAIN -> AriaMainDashboard(onScreenChange, onRadioToggle = { viewModel.toggleRadio() })
            AriaSubScreen.ADHKAR -> AdhkarDetail(viewModel.adhkarList, onBack = { onScreenChange(AriaSubScreen.MAIN) })
            AriaSubScreen.NAMES -> NamesDetail(viewModel.namesOfAllah, onBack = { onScreenChange(AriaSubScreen.MAIN) })
            AriaSubScreen.TASBIH -> TasbihDetail(tasbihCount, viewModel.tasbihPhrases, onIncrement = { viewModel.incrementTasbih() }, onReset = { viewModel.resetTasbih() }, onBack = { onScreenChange(AriaSubScreen.MAIN) }, onSuccess = onSuccessComplete)
            AriaSubScreen.QIBLA -> QiblaDetail(onBack = { onScreenChange(AriaSubScreen.MAIN) })
            AriaSubScreen.HOLIDAYS -> HolidaysDetail(viewModel.uiState.value.holidays, onBack = { onScreenChange(AriaSubScreen.MAIN) })
        }
    }
}

@Composable
fun AriaMainDashboard(onScreenChange: (AriaSubScreen) -> Unit, onRadioToggle: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ركن اريا الإسلامي",
            style = TextStyle(color = GoldPure, fontSize = 22.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                AriaGridCard(title = "أذكار المسلم", subtitle = "20 ذكراً ودعاءً مأثوراً", icon = Icons.Default.Favorite, onClick = { onScreenChange(AriaSubScreen.ADHKAR) })
            }
            item {
                AriaGridCard(title = "ابني جنتك", subtitle = "السبحة الإلكترونية الذكية", icon = Icons.Default.Star, onClick = { onScreenChange(AriaSubScreen.TASBIH) })
            }
            item {
                AriaGridCard(title = "الإذاعة الفورية", subtitle = "راديو القرآن مباشر", icon = Icons.Default.Radio, onClick = { onRadioToggle() })
            }
            item {
                AriaGridCard(title = "اتجاه القبلة", subtitle = "حساب زاوية القبلة الفلكية", icon = Icons.Default.Explore, onClick = { onScreenChange(AriaSubScreen.QIBLA) })
            }
            item {
                AriaGridCard(title = "أسماء الله الحسنى", subtitle = "التدبر في المكتوب", icon = Icons.Default.AutoAwesome, onClick = { onScreenChange(AriaSubScreen.NAMES) })
            }
            item {
                AriaGridCard(title = "المناسبات الدينية", subtitle = "الملاحظات والشعائر", icon = Icons.Default.CalendarMonth, onClick = { onScreenChange(AriaSubScreen.HOLIDAYS) })
            }
        }
    }
}

@Composable
fun AriaGridCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = SageLight),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, GoldPure.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(GoldGradient, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = "Aria Tool", tint = EmeraldDark, modifier = Modifier.size(20.dp))
            }
            Column {
                Text(title, color = EmeraldDark, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = EmeraldDark.copy(alpha = 0.5f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// 4A. ADHKAR SCREENS COZY VIEW
@Composable
fun AdhkarDetail(adhkar: List<String>, onBack: () -> Unit) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPure) }
            Spacer(modifier = Modifier.width(12.dp))
            Text("أذكار المسلم اليومية", style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(adhkar) { pray ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SageLight),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = pray,
                            style = TextStyle(
                                color = EmeraldDark,
                                fontSize = 18.sp,
                                fontFamily = FontFamily.Serif,
                                textAlign = TextAlign.Right,
                                lineHeight = 28.sp
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(pray))
                                }
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = GoldDeep, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ الذكر", color = GoldDeep, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4B. NAMES OF ALLAH GRID VIEW
@Composable
fun NamesDetail(names: List<String>, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPure) }
            Spacer(modifier = Modifier.width(12.dp))
            Text("أسماء الله الحسنى", style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold))
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(names) { name ->
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .border(1.dp, GoldPure.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = name,
                        style = TextStyle(
                            color = GoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        }
    }
}

// 4C. DIGITAL COMPASS VIEW (QIBLA DIRECTION)
@Composable
fun QiblaDetail(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPure) }
            Spacer(modifier = Modifier.width(12.dp))
            Text("اتجاه القبلة", style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold))
        }

        // Animated rotating gold-gilded dial
        val angleOffset = 136f //Cairo Qibla angle
        val infiniteTransition = rememberInfiniteTransition(label = "compass")
        val wiggleAngle by infiniteTransition.animateFloat(
            initialValue = -3f,
            targetValue = 3f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "wiggle"
        )

        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.03f))
                .border(2.dp, GoldPure.copy(alpha = 0.4f), CircleShape)
                .rotate(angleOffset + wiggleAngle),
            contentAlignment = Alignment.Center
        ) {
            // Draw compass rings
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(color = GoldPure, radius = size.minDimension / 2f - 12.dp.toPx(), style = Stroke(width = 1.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)))
            }
            Icon(
                imageVector = Icons.Default.Navigation,
                contentDescription = "Arrow",
                tint = GoldShiny,
                modifier = Modifier
                    .size(80.dp)
                    .rotate(45f) // Correct vector offset direction
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SageLight),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "قبلة الصلاة لجمهورية مصر العربية",
                    style = TextStyle(color = EmeraldDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "اتجاه القبلة هو 136° درجة باتجاه الشرق من الشمال المغناطيسي الدقيق لموقعك.",
                    style = TextStyle(color = EmeraldDark.copy(alpha = 0.7f), fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 20.sp)
                )
            }
        }
    }
}

// 4D. DIGITAL TASBIH INTERACTIVE COUNTER
@Composable
fun TasbihDetail(
    tasbihCount: Int,
    phrases: List<String>,
    onIncrement: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit,
    onSuccess: (String) -> Unit
) {
    // Determine active phrase in cyclical iterations of 33 ticks
    val phraseIndex = (tasbihCount / 33) % phrases.size
    val activePhrase = phrases[phraseIndex]

    // Watch for 33 milestones to trigger a congratulations popup
    LaunchedEffect(tasbihCount) {
        if (tasbihCount > 0 && tasbihCount % 33 == 0) {
            onSuccess("إنجاز رائع! أكملت 33 تسبيحة مأثورة. \nبارك الله لك في ذكرك!")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPure) }
                Spacer(modifier = Modifier.width(12.dp))
                Text("ابني جنتك", style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold))
            }

            // Big centered target counter
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(3.dp, GoldPure, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = tasbihCount.toString(),
                        style = TextStyle(color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black)
                    )
                    Text("تسبيحة", color = GoldPure, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Active dhikr capsule
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF022C22)),
                border = BorderStroke(1.dp, GoldPure.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activePhrase,
                        style = TextStyle(
                            color = GoldLight,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main click button styled in lush Gold
            Button(
                onClick = onIncrement,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPure)
            ) {
                Text("سَبِّحْ", color = EmeraldDark, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reset action link
            Text(
                text = "تصفير العداد",
                color = Color.White.copy(alpha = 0.3f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onReset() }
                    .padding(8.dp)
            )
        }
    }
}

// 4E. HOLIDAYS/OCCASIONS LIST SCREEN
@Composable
fun HolidaysDetail(holidays: List<String>, onBack: () -> Unit) {
    val fallbackHolidays = listOf(
        "المولد النبوي الشريف - 12 ربيع الأول",
        "ليلة الإسراء والمعراج - 27 رجب",
        "ليلة النصف من شعبان - 15 شعبان",
        "عيد الفطر المبارك - 1 شوال",
        "يوم عرفة - 9 ذو الحجة",
        "عيد الأضحى المبارك - 10 ذو الحجة",
        "رأس السنة الهجرية - 1 محرم"
    )
    val displayHolidays = if (holidays.isEmpty()) fallbackHolidays else holidays

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPure) }
            Spacer(modifier = Modifier.width(12.dp))
            Text("المناسبات الإسلامية", style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(displayHolidays) { hol ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SageLight),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = hol,
                            style = TextStyle(
                                color = EmeraldDark,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Right
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

// 5. --- GENERAL UTILS COMPONENT ---
@Composable
fun AudioVisualizer(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")
    
    // Smooth infinite breathing height loops
    val height1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "anim_h1"
    )
    val height2 by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "anim_h2"
    )
    val height3 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "anim_h3"
    )

    Row(
        modifier = modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val bars = listOf(height1, height2, height3)
        bars.forEach { heightVal ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(heightVal)
                    .background(GoldPure)
            )
        }
    }
}
